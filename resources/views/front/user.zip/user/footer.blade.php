<footer class="userFooter">
    <div class="col-12">
        <div class="col-10 d-flex justify-content-between m-auto user-content">
            <div class="copyright">
                <p class="m-0">Copyright © 2018-2021 Online Gym project. All Rights Reserved.
                </p>
            </div>
            <div class="d-flex align-items-center justify-content-center promodex">
                <p class="m-0 mr-2">Разработано:</p><img src="/images/PROMODEX.png" alt="">
            </div>
        </div>
    </div>
</footer>
